from django.apps import AppConfig


class SocialConfig(AppConfig):
    name = 'apps.social'
